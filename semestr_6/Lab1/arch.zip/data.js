{
	"age": 20, 
	"phone": "+73539215818", 
	"name": "Anna", 
	"city": "Vienna" 
}