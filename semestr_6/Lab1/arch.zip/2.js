{
	"age": 35, 
	"phone": "+73539215818", 
	"name": "Andrei", 
	"city": "Moscow" 
}