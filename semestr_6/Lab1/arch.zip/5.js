{
	"age": 27, 
	"phone": "+73539215848", 
	"name": "Anna", 
	"city": "Kemerovo" 
}