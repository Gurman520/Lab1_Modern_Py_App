{
	"age": 57, 
	"phone": "+73539215818", 
	"name": "Soni", 
	"city": "Moscow" 
}